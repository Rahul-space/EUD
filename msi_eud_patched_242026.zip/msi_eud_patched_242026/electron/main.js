'use strict';

/**
 * Cognix EUD AI Assist — Electron Main Process
 * ===================================
 * Startup sequence:
 *  1. app.ready → single-instance lock → start Python backend
 *  2. Backend ready → create tray icon → start alert poller
 *  3. Alert fires → popup window in bottom-right corner
 *  4. User clicks tray → open dashboard window
 *
 * All Python logic (monitoring, AI, FastAPI) is unchanged.
 * Electron is purely the UI/tray shell around the Python backend.
 */

const {
  app, Menu, dialog, powerMonitor,
} = require('electron');

const path           = require('path');
const backendManager = require('./backend-manager');
const trayManager    = require('./tray-manager');
const windowManager  = require('./window-manager');
const alertPoller    = require('./alert-poller');

// ── Single instance lock ────────────────────────────────────────────────────
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  // Another instance is already running — focus its window
  app.quit();
  process.exit(0);
}

app.on('second-instance', () => {
  windowManager.openDashboard();
});

// ── App flags ───────────────────────────────────────────────────────────────
app.setAppUserModelId('com.cognix.eud.assist');       // Windows taskbar grouping
app.disableHardwareAcceleration();                  // Lighter, no GPU needed for monitoring UI
app.commandLine.appendSwitch('disable-background-networking');
app.commandLine.appendSwitch('disable-default-apps');

// Prevent multiple display in taskbar for tray apps
if (process.platform === 'win32') {
  app.setLoginItemSettings({ openAtLogin: false });   // handled by installer
}

// ── Dev tools toggle ─────────────────────────────────────────────────────────
const IS_DEV = process.argv.includes('--dev') || !app.isPackaged;

// ── Main startup ─────────────────────────────────────────────────────────────
app.whenReady().then(async () => {
  // Suppress default menu bar
  Menu.setApplicationMenu(null);

  // Register all IPC handlers
  windowManager.registerIPC();

  // Show "starting" tray immediately so user sees something
  trayManager.create();
  trayManager.setBackendReady(false);

  // Wire tray callbacks
  trayManager.onOpenDashboard = () => windowManager.openDashboard();
  trayManager.onOpenChat      = () => windowManager.openDashboard('/chat');
  trayManager.onTogglePause   = () => togglePause();
  trayManager.onQuit          = () => quitApp();

  // Start Python backend
  console.log('[Main] Starting Python backend…');
  try {
    await backendManager.start();
    console.log('[Main] Backend ready ✓');
    if (IS_DEV || !app.isPackaged) {

     windowManager.openBot();
    }
  } catch (err) {
    console.error('[Main] Backend failed to start:', err.message);
    dialog.showErrorBox(
      'Cognix EUD AI Assist — Backend Error',
      `The monitoring agent failed to start.\n\n${err.message}\n\n` +
      `Check logs in:\n${app.getPath('logs')}`
    );
    app.exit(1);
    return;
  }

  // Backend is ready
  trayManager.setBackendReady(true);
  backendManager.onCrash((n) => {
    trayManager.setBackendReady(false);
    console.warn(`[Main] Backend crashed (restart ${n})`);
    setTimeout(() => trayManager.setBackendReady(backendManager.isReady), 5000);
  });

  // Wire alert poller → tray + popup + CHAT
  alertPoller.onAlertCount   = (n)            => trayManager.setAlertCount(n);
  alertPoller.onHealth       = (score, label) => trayManager.setHealth(score, label);
  alertPoller.onPausedChange = (paused)       => trayManager.setPaused(paused);
  alertPoller.onPopupNeeded  = (id, metric, severity, msg, remediations) => {
    // Build alert payload for the chat window
    const alertPayload = { alertId: id, metric, severity, message: msg, remediations };

    // Push alert into the floating chat window (auto-opens it)
    windowManager.sendToChat('chat:alert-injected', alertPayload);

    // Also send to legacy popup channel so any open popup window stays in sync
    if (windowManager.isPopupOpen()) {
      windowManager.sendToPopup('alert-data', alertPayload);
    }
  };
  alertPoller.start();

  // Open dashboard on first launch (disabled for )
  if (IS_DEV || !app.isPackaged) {
    //windowManager.openDashboard();
    windowManager.openBot();
  }
  // In production, just sit in tray until user clicks

  // ── Power monitor: pause on sleep / resume on wake ───────────────────────
  powerMonitor.on('suspend', () => {
    console.log('[Main] System suspend — backend will pause naturally');
  });
  powerMonitor.on('resume', () => {
    console.log('[Main] System resume — reconnecting poller');
    setTimeout(() => alertPoller.start(), 2000);
  });
});

// ── Quit handling ─────────────────────────────────────────────────────────────
app.on('window-all-closed', (e) => {
  // Do NOT quit when all windows close — stay in tray
  e.preventDefault?.();
});

app.on('before-quit', () => {
  alertPoller.stop();
  backendManager.stop();
});

app.on('will-quit', () => {
  alertPoller.stop();
  backendManager.stop();
});

// ── Helpers ───────────────────────────────────────────────────────────────────
async function togglePause() {
  try {
    const url    = `${backendManager.apiBase}/api/monitoring`;
    const http   = require('http');
    // Check current state first
    const status = await httpGet(`${backendManager.apiBase}/api/monitoring/status`);
    const paused = status?.paused;
    await httpPost(`${backendManager.apiBase}/api/monitoring/${paused ? 'resume' : 'pause'}`);
  } catch (e) {
    console.error('[Main] Toggle pause error:', e.message);
  }
}

function quitApp() {
  alertPoller.stop();
  backendManager.stop();
  app.exit(0);
}

function httpGet(url) {
  return new Promise((resolve) => {
    const http = require('http');
    http.get(url, { timeout: 3000 }, (res) => {
      let body = '';
      res.on('data', d => body += d);
      res.on('end', () => { try { resolve(JSON.parse(body)); } catch(_) { resolve(null); } });
    }).on('error', () => resolve(null));
  });
}

function httpPost(url) {
  return new Promise((resolve) => {
    const http = require('http');
    const req  = http.request(url, { method: 'POST', timeout: 3000 }, (res) => {
      res.resume();
      resolve(res.statusCode);
    });
    req.on('error', () => resolve(null));
    req.write('{}');
    req.end();
  });
}
