'use strict';

/**
 * AlertPoller
 * ===========
 * Connects to the Python backend WebSocket (/ws) from the main process.
 * Drives:
 *   - Tray badge count (alert count)
 *   - Tray health colour
 *   - Popup window trigger when new critical/warning alerts arrive
 *   - Native desktop notifications (Electron Notification API)
 */

const { Notification } = require('electron');
const WebSocket        = require('ws');    // bundled with Electron

const WS_URL           = 'ws://127.0.0.1:8765/ws';
const RECONNECT_DELAY  = 3000;
const PING_INTERVAL    = 20000;

class AlertPoller {
  constructor() {
    this._ws            = null;
    this._pingTimer     = null;
    this._reconnTimer   = null;
    this._running       = false;
    this._lastAlertIds  = new Set();   // prevents re-showing same popup

    // Injected callbacks
    this.onAlertCount   = null;    // fn(n)
    this.onHealth       = null;    // fn(score, label)
    this.onPopupNeeded  = null;    // fn(alertId, metric, severity, message)
    this.onPausedChange = null;    // fn(paused)
  }

  start() {
    this._running = true;
    this._connect();
  }

  stop() {
    this._running = false;
    this._clearTimers();
    if (this._ws) { try { this._ws.close(); } catch(_) {} }
  }

  _connect() {
    try {
      this._ws = new WebSocket(WS_URL);
    } catch(e) {
      this._scheduleReconnect();
      return;
    }

    this._ws.on('open', () => {
      console.log('[AlertPoller] WebSocket connected');
      this._pingTimer = setInterval(() => {
        if (this._ws?.readyState === 1) {
          this._ws.send(JSON.stringify({ type: 'ping' }));
        }
      }, PING_INTERVAL);
    });

    this._ws.on('message', (raw) => {
      try {
        const data = JSON.parse(raw.toString());
        if (data.type === 'metrics') this._handleMetrics(data);
      } catch (_) {}
    });

    this._ws.on('close',  () => { this._clearTimers(); this._scheduleReconnect(); });
    this._ws.on('error',  () => { this._clearTimers(); this._scheduleReconnect(); });
  }

  _handleMetrics(data) {
    // Update tray badge
    const summary    = data.alert_summary || {};
    const alertCount = summary.total_active || 0;
    if (this.onAlertCount) this.onAlertCount(alertCount);

    // Update tray health
    if (this.onHealth) this.onHealth(data.health_score || 0, data.health_label || 'Unknown');

    // Paused state
    if (this.onPausedChange) this.onPausedChange(!!data.paused);

    // Check for new popups needed
    const activeStates = data.active_states || [];
    const critical = activeStates.find(s => s.severity === 'critical' && s.phase === 'POPUP_SHOWN');
    const warning  = activeStates.find(s => s.severity === 'warning'  && s.phase === 'POPUP_SHOWN');
    const toShow   = critical || warning;

    if (toShow && !this._lastAlertIds.has(toShow.alert_id)) {
      this._lastAlertIds.add(toShow.alert_id);
      // Keep set lean
      if (this._lastAlertIds.size > 50) {
        const first = this._lastAlertIds.values().next().value;
        this._lastAlertIds.delete(first);
      }

      // Desktop notification
      this._sendDesktopNotification(toShow);

      // Trigger popup / chat window
      if (this.onPopupNeeded) {
        // Build suggested remediations based on metric so the chat can show buttons
        const remediations = this._guessRemediations(toShow.metric, toShow.severity);
        this.onPopupNeeded(
          toShow.alert_id,
          toShow.metric,
          toShow.severity,
          toShow.message || toShow.diagnosis || '',
          remediations
        );
      }
    }
  }

  _sendDesktopNotification(alert) {
    try {
      if (!Notification.isSupported()) return;
      const icons = { critical: '🔴', warning: '⚠️', info: 'ℹ️' };
      new Notification({
        title:   `${icons[alert.severity] || '⚠️'} Cognix EUD AI Assist — ${(alert.severity||'').toUpperCase()}`,
        body:    alert.message || 'System issue detected',
        silent:  false,
        urgency: alert.severity === 'critical' ? 'critical' : 'normal',
      }).show();
    } catch(e) {
      console.error('[AlertPoller] Notification error:', e.message);
    }
  }

  /** Return suggested remediation buttons for the chat UI based on metric. */
  _guessRemediations(metric, severity) {
    const m = (metric || '').toLowerCase();
    if (m.includes('cpu'))
      return [
        { action: 'kill_top_process', label: '🛑 Kill Top Process' },
        { action: 'optimize_memory',  label: '🧹 Free Memory' },
      ];
    if (m.includes('mem') || m.includes('ram'))
      return [
        { action: 'optimize_memory',  label: '🧹 Free Memory' },
        { action: 'kill_top_process', label: '🛑 Kill Top Process' },
      ];
    if (m.includes('disk'))
      return [
        { action: 'clear_temp', label: '🗑 Clear Temp Files' },
      ];
    if (m.includes('net') || m.includes('network'))
      return [
        { action: 'reset_network', label: '🔄 Reset Network' },
      ];
    if (m.includes('security') || m.includes('threat'))
      return [
        { action: 'kill_top_process', label: '🛡 Terminate Threat' },
      ];
    // Generic fallback
    return [
      { action: 'optimize_memory', label: '🧹 Auto Remediate' },
      { action: 'clear_temp',      label: '🗑 Clear Temp' },
    ];
  }

  _scheduleReconnect() {
    if (!this._running) return;
    this._reconnTimer = setTimeout(() => {
      if (this._running) this._connect();
    }, RECONNECT_DELAY);
  }

  _clearTimers() {
    if (this._pingTimer)  { clearInterval(this._pingTimer);  this._pingTimer  = null; }
    if (this._reconnTimer){ clearTimeout(this._reconnTimer); this._reconnTimer= null; }
  }
}

module.exports = new AlertPoller();
