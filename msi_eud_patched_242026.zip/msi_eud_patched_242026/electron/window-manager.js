'use strict';

const { BrowserWindow, screen, ipcMain } = require('electron');
const path = require('path');

const BACKEND_PORT = 8765;
const BACKEND_URL = `http://127.0.0.1:${BACKEND_PORT}`;

class WindowManager {
  constructor() {
    this._dashboard = null;
    this._bot = null;
    this._popup = null;   // ✅ added
  }

  // ── DASHBOARD ─────────────────────────────

  openDashboard(route = '') {
    if (this._dashboard && !this._dashboard.isDestroyed()) {
      this._dashboard.show();
      this._dashboard.focus();
      if (route) this._dashboard.loadURL(`${BACKEND_URL}${route}`);
      return;
    }

    this._dashboard = new BrowserWindow({
      width: 1280,
      height: 780,
      autoHideMenuBar: true,
      webPreferences: {
        preload: path.join(__dirname, 'preload.js'),
        contextIsolation: true,
      },
    });

    this._dashboard.loadURL(`${BACKEND_URL}${route}`);
  }

  // ── BOT ───────────────────────────────────

  openBot() {
    if (this._bot && !this._bot.isDestroyed()) {
      this._bot.show();
      this._bot.focus();
      return;
    }

    this._bot = new BrowserWindow({
      width: 100,
      height: 100,
      frame: false,
      transparent: true,
      alwaysOnTop: true,
      resizable: false,
      skipTaskbar: true,
      hasShadow: false,
      webPreferences: {
        preload: path.join(__dirname, 'preload.js'),
      },
    });

    // ✅ POSITION
    const display = screen.getPrimaryDisplay();
    const { x, y, width, height } = display.workArea;

    const botWidth = 100;
    const botHeight = 100;

    const marginX = 20;
    const marginY = 20;

    this._bot.setPosition(
      x + width - botWidth - marginX,
      y + height - botHeight - marginY
    );

    this._bot.loadFile(path.join(__dirname, 'bot.html'));

    this._bot.once('ready-to-show', () => {
      this._bot.show();
    });

    this._bot.on('closed', () => {
      this._bot = null;
    });
  }

  // ── CHAT POPUP ───────────────────────────

  openChat() {
    if (this._popup && !this._popup.isDestroyed()) {
      this._popup.show();
      this._popup.focus();
      return;
    }

    const { workArea } = screen.getPrimaryDisplay();

    const width = 350;
    const height = 500;

    const x = workArea.x + workArea.width - width - 20;
    const y = workArea.y + workArea.height - height - 20;

    this._popup = new BrowserWindow({
      width,
      height,
      x,
      y,
      frame: false,
      resizable: false,
      alwaysOnTop: true,
      skipTaskbar: true,
      webPreferences: {
        preload: path.join(__dirname, 'preload.js'),
      },
    });

    this._popup.loadFile(path.join(__dirname, 'chat.html'));

    this._popup.on('closed', () => {
      this._popup = null;
    });
  }

  closeChat() {
    if (this._popup && !this._popup.isDestroyed()) {
      this._popup.close();
    }
  }

  // ── Alert → chat bridge ───────────────────
  //  Sends an alert payload into chat.html via IPC.
  //  Auto-opens the chat window and brings it to front.
  sendToChat(channel, payload) {
    if (!this.isChatOpen()) {
      this.openChat();
      // Push message once page has loaded
      this._popup.webContents.once('did-finish-load', () => {
        this._popup.webContents.send(channel, payload);
      });
    } else {
      this._popup.webContents.send(channel, payload);
    }
    // Always surface the chat window so user sees the alert
    this._popup.show();
    this._popup.focus();
  }

  isChatOpen() {
    return !!(this._popup && !this._popup.isDestroyed());
  }

  // Backward-compat aliases used in main.js
  isPopupOpen()             { return this.isChatOpen(); }
  sendToPopup(ch, payload)  { this.sendToChat(ch, payload); }

  // ── IPC ───────────────────────────────────

  registerIPC() {
    ipcMain.on('dashboard:open', (_, route) => {
      this.openDashboard(route || '');
    });
    ipcMain.on('chat:open',  () => this.openChat());
    ipcMain.on('chat:close', () => this.closeChat());
  }
}

module.exports = new WindowManager();



