'use strict';

/**
 * TrayManager
 * ===========
 * Manages the system-tray icon with a dynamic notification badge.
 *
 * On Windows, Electron does not natively support badge overlays on tray icons,
 * so we composite a badge (red circle + number) onto the icon using nativeImage
 * canvas drawing whenever the alert count changes.
 *
 * Badge behaviour:
 *   0 alerts  →  plain teal icon
 *   1–9       →  badge with number
 *   10+       →  badge with "9+"
 */

const { Tray, Menu, nativeImage, app } = require('electron');
const path    = require('path');
const fs      = require('fs');

const ASSETS  = path.join(__dirname, 'assets');
const ICON_W  = 16;   // Windows tray icon size
const ICON_H  = 16;

class TrayManager {
  constructor() {
    this._tray        = null;
    this._alertCount  = 0;
    this._health      = { score: 100, label: 'Loading' };
    this._paused      = false;
    this._backendReady= false;

    // Callbacks injected by main.js
    this.onOpenDashboard  = null;
    this.onOpenChat       = null;
    this.onTogglePause    = null;
    this.onViewHealth     = null;
    this.onQuit           = null;
  }

  // ── Public API ──────────────────────────────────────────────────────────

  create() {
    const img   = this._buildIcon(0, true);
    this._tray  = new Tray(img);
    this._tray.setToolTip('Cognix EUD AI Assist — Starting…');
    this._buildMenu();

    this._tray.on('click',        () => this.onOpenDashboard && this.onOpenDashboard());
    this._tray.on('double-click', () => this.onOpenDashboard && this.onOpenDashboard());

    return this._tray;
  }

  setAlertCount(n) {
    if (this._alertCount === n) return;
    this._alertCount = n;
    this._refreshIcon();
    this._buildMenu();
  }

  setHealth(score, label) {
    this._health = { score, label };
    this._updateTooltip();
    this._refreshIcon();
    this._buildMenu();
  }

  setPaused(paused) {
    this._paused = paused;
    this._updateTooltip();
    this._buildMenu();
  }

  setBackendReady(ready) {
    this._backendReady = ready;
    this._updateTooltip();
    this._refreshIcon();
    this._buildMenu();
  }

  // ── Icon drawing ─────────────────────────────────────────────────────────

  _refreshIcon() {
    if (!this._tray) return;
    try {
      this._tray.setImage(this._buildIcon(this._alertCount, !this._backendReady));
    } catch (e) {
      console.error('[TrayManager] Icon refresh error:', e.message);
    }
  }

  _buildIcon(alertCount, loading = false) {
    // Try loading a pre-built icon first
    const icoPath = path.join(ASSETS, loading ? 'tray-loading.png' :
      this._health.score >= 80 ? 'tray-green.png' :
      this._health.score >= 55 ? 'tray-yellow.png' : 'tray-red.png');

    let base;
    if (fs.existsSync(icoPath)) {
      base = nativeImage.createFromPath(icoPath).resize({ width: ICON_W, height: ICON_H });
    } else {
      // Fallback: generate icon programmatically using data URL
      base = this._generateBaseIcon(loading);
    }

    if (alertCount <= 0) return base;

    // Composite badge onto the icon
    return this._addBadge(base, alertCount);
  }

  _generateBaseIcon(loading) {
    const score  = this._health.score;
    const color  = loading ? '#666666'
      : score >= 80 ? '#00d4a0'
      : score >= 55 ? '#f59e0b'
      : '#ef4444';

    // Create a 64×64 PNG via data URL (will be resized by Electron)
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64">
      <rect width="64" height="64" rx="12" fill="#0d0f14"/>
      <circle cx="32" cy="32" r="26" fill="${color}"/>
      <text x="32" y="41" font-family="Arial" font-size="26" font-weight="bold"
            fill="#0d0f14" text-anchor="middle">S</text>
    </svg>`;

    // Convert SVG to data URL as PNG placeholder
    // Electron's nativeImage can read from buffer
    const dataUrl = `data:image/svg+xml;base64,${Buffer.from(svg).toString('base64')}`;
    return nativeImage.createFromDataURL(dataUrl).resize({ width: ICON_W, height: ICON_H });
  }

  _addBadge(baseImage, count) {
    // We composite a red circle with the count number into the bottom-right quadrant.
    // We do this by building a new nativeImage from a data URL containing both.
    const label   = count > 9 ? '9+' : String(count);
    const size    = 64;
    const bs      = 24;   // badge size
    const bx      = size - bs;
    const by      = size - bs;
    const fontSize= count > 9 ? 12 : 15;

    const baseDataUrl = baseImage.resize({ width: size, height: size }).toDataURL();

    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}">
      <image href="${baseDataUrl}" width="${size}" height="${size}"/>
      <circle cx="${bx + bs/2}" cy="${by + bs/2}" r="${bs/2}" fill="#ef4444"/>
      <text x="${bx + bs/2}" y="${by + bs/2 + fontSize*0.35}"
            font-family="Arial" font-size="${fontSize}" font-weight="bold"
            fill="white" text-anchor="middle">${label}</text>
    </svg>`;

    const dataUrl = `data:image/svg+xml;base64,${Buffer.from(svg).toString('base64')}`;
    return nativeImage.createFromDataURL(dataUrl).resize({ width: ICON_W, height: ICON_H });
  }

  // ── Context menu ─────────────────────────────────────────────────────────

  _buildMenu() {
    if (!this._tray) return;

    const alertLabel = this._alertCount > 0
      ? `🔴 ${this._alertCount} Active Alert${this._alertCount > 1 ? 's' : ''}`
      : '✅ No Active Alerts';

    const healthLabel = this._backendReady
      ? `Health: ${this._health.score}/100 — ${this._health.label}`
      : 'Backend starting…';

    const menu = Menu.buildFromTemplate([
      { label: 'Cognix EUD AI Assist  v2.2.0', enabled: false,
        icon: this._backendReady ? undefined : undefined },
      { type: 'separator' },
      { label: '📊 Open Dashboard',
        click: () => this.onOpenDashboard && this.onOpenDashboard() },
      { label: '💬 Open AI Chat',
        click: () => this.onOpenChat && this.onOpenChat() },
      { type: 'separator' },
      { label: healthLabel,   enabled: false },
      { label: alertLabel,    enabled: false },
      { type: 'separator' },
      { label: this._paused ? '▶  Resume Monitoring' : '⏸  Pause Monitoring',
        click: () => this.onTogglePause && this.onTogglePause() },
      { type: 'separator' },
      { label: '✕  Quit Cognix EUD AI Assist',
        click: () => this.onQuit && this.onQuit() },
    ]);

    this._tray.setContextMenu(menu);
  }

  _updateTooltip() {
    if (!this._tray) return;
    const paused = this._paused ? ' [PAUSED]' : '';
    const alerts = this._alertCount > 0 ? ` | ⚠ ${this._alertCount} alert(s)` : '';
    this._tray.setToolTip(
      this._backendReady
        ? `Cognix EUD AI Assist — ${this._health.score}/100 ${this._health.label}${alerts}${paused}`
        : 'Cognix EUD AI Assist — Starting backend…'
    );
  }
}

module.exports = new TrayManager();
