'use strict';

/**
 * BackendManager — Silent Background Execution
 * =============================================
 * Spawns the Python FastAPI backend completely silently:
 *  - windowsHide: true            → no CMD/console window
 *  - stdio: ['ignore','ignore','pipe'] → no output pipe overhead
 *  - DETACHED_PROCESS flag via env → fully background
 *
 * Production: resources/backend/SysAssistBackend.exe (PyInstaller)
 * Development: python main.py --agent
 *
 * Auto-restarts on crash (max 5). Health-checked every 10s.
 */

const { app }   = require('electron');
const { spawn } = require('child_process');
const path      = require('path');
const fs        = require('fs');
const http      = require('http');

const PORT            = 8765;
const HOST            = '127.0.0.1';
const HEALTH_URL      = `http://${HOST}:${PORT}/api/metrics`;
const MAX_RESTARTS    = 5;
const RESTART_DELAY   = 3500;
const HEALTH_INTERVAL = 12000;
const STARTUP_TIMEOUT = 35000;

// Windows process creation flags
const CREATE_NO_WINDOW       = 0x08000000;
const DETACHED_PROCESS       = 0x00000008;
const SILENT_FLAGS           = CREATE_NO_WINDOW | DETACHED_PROCESS;

class BackendManager {
  constructor() {
    this._proc         = null;
    this._restarts     = 0;
    this._healthTimer  = null;
    this._startupTimer = null;
    this._ready        = false;
    this._onReadyCb    = null;
    this._onCrashCb    = null;
    this._stopping     = false;
    this._logBuffer    = [];
  }

  start() {
    return new Promise((resolve, reject) => {
      this._onReadyCb = resolve;
      this._launch();
      this._startupTimer = setTimeout(() => {
        if (!this._ready)
          reject(new Error(`Backend did not respond within ${STARTUP_TIMEOUT/1000}s`));
      }, STARTUP_TIMEOUT);
    });
  }

  stop() {
    this._stopping = true;
    this._clearTimers();
    if (this._proc) {
      try { this._proc.kill('SIGTERM'); } catch (_) {}
      setTimeout(() => {
        try { if (this._proc) this._proc.kill('SIGKILL'); } catch (_) {}
      }, 3000);
    }
  }

  onCrash(fn) { this._onCrashCb = fn; }
  get isReady()  { return this._ready; }
  get apiBase()  { return `http://${HOST}:${PORT}`; }
  get logLines() { return this._logBuffer.slice(-50); }

  _resolveBinaryPath() {
    if (app.isPackaged) {
      const exe = process.platform === 'win32'
        ? 'SysAssistBackend.exe' : 'SysAssistBackend';
      return path.join(process.resourcesPath, 'backend', exe);
    }
    return null;
  }

  _launch() {
    const exePath = this._resolveBinaryPath();
    const env = {
      ...process.env,
      SYSASSIST_SERVICE_MODE: '1',
      PYTHONUNBUFFERED: '1',
    };

    // Silent spawn options — no window, no console
    const spawnOpts = {
      detached:    false,
      stdio:       ['ignore', 'pipe', 'pipe'],
      windowsHide: true,
      env,
    };

    // On Windows: also set creationflags for total silence
    if (process.platform === 'win32') {
      spawnOpts.creationflags = CREATE_NO_WINDOW;
    }

    let proc;
    if (exePath && fs.existsSync(exePath)) {
      proc = spawn(exePath, ['--agent'], spawnOpts);
    } else {
      // Development — find python
      const pythonCmd = process.platform === 'win32' ? 'pythonw' : 'python3';
      const fallback  = process.platform === 'win32' ? 'python'  : 'python3';
      let script = path.join(__dirname, '..', 'main.py');
      if (!fs.existsSync(script)) {
        const appPath = app.getAppPath ? app.getAppPath() : __dirname;
        script = path.join(appPath, '..', 'main.py');
      }

      proc = spawn(pythonCmd, [script, '--agent'], spawnOpts);
      proc.on('error', () => {
        // pythonw failed — retry with python
        proc = spawn(fallback, [script, '--agent'], spawnOpts);
        this._proc = proc;
        this._attachListeners(proc);
      });
    }

    this._proc = proc;
    this._attachListeners(proc);
    this._pollReady();
  }

  _attachListeners(proc) {
    // Capture stderr to log buffer (never shown to user)
    if (proc.stderr) {
      proc.stderr.on('data', d => {
        const msg = d.toString().trim();
        if (msg) this._logBuffer.push(`[${new Date().toISOString()}] ${msg}`);
        if (this._logBuffer.length > 200) this._logBuffer.shift();
      });
    }
    if (proc.stdout) {
      proc.stdout.on('data', d => {
        const msg = d.toString().trim();
        if (msg) this._logBuffer.push(`[out] ${msg}`);
        if (this._logBuffer.length > 200) this._logBuffer.shift();
      });
    }
    proc.on('exit', (code, signal) => {
      this._logBuffer.push(`[exit] code=${code} signal=${signal}`);
      this._ready = false;
      this._proc  = null;
      if (!this._stopping) this._handleCrash();
    });
  }

  _pollReady() {
    let attempts = 0;
    const poll = setInterval(() => {
      attempts++;
      this._checkHealth().then(ok => {
        if (ok && !this._ready) {
          this._ready = true;
          clearInterval(poll);
          clearTimeout(this._startupTimer);
          this._startHealthMonitor();
          if (this._onReadyCb) { this._onReadyCb(); this._onReadyCb = null; }
        }
        if (attempts > 120) clearInterval(poll); // 60s max polling
      });
    }, 500);
  }

  _startHealthMonitor() {
    this._healthTimer = setInterval(async () => {
      const ok = await this._checkHealth();
      if (!ok && this._ready && !this._stopping) {
        this._logBuffer.push('[health] check failed — marking not-ready');
        this._ready = false;
      }
    }, HEALTH_INTERVAL);
  }

  _handleCrash() {
    this._restarts++;
    if (this._onCrashCb) this._onCrashCb(this._restarts);
    if (this._restarts <= MAX_RESTARTS) {
      const delay = RESTART_DELAY * Math.min(this._restarts, 3); // back-off
      this._logBuffer.push(`[restart] attempt ${this._restarts}/${MAX_RESTARTS} in ${delay}ms`);
      setTimeout(() => { if (!this._stopping) this._launch(); }, delay);
    } else {
      this._logBuffer.push('[restart] max restarts exceeded — giving up');
    }
  }

  _checkHealth() {
    return new Promise(resolve => {
      const req = http.get(HEALTH_URL, { timeout: 2500 }, res => {
        resolve(res.statusCode < 500);
        res.resume();
      });
      req.on('error',   () => resolve(false));
      req.on('timeout', () => { req.destroy(); resolve(false); });
    });
  }

  _clearTimers() {
    if (this._healthTimer)  { clearInterval(this._healthTimer);  this._healthTimer  = null; }
    if (this._startupTimer) { clearTimeout(this._startupTimer);  this._startupTimer = null; }
  }
}

module.exports = new BackendManager();
