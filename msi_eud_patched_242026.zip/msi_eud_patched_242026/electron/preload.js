'use strict';

/**
 * Preload Script
 * ==============
 * Exposes a secure, minimal API to the renderer pages via contextBridge.
 * No Node.js APIs leak to renderer — renderer only gets what's listed here.
 */

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {

  // ── Window controls ────────────────────────────────────────────────────
  closePopup:     ()      => ipcRenderer.send('popup:close'),
  expandToFull:   ()      => ipcRenderer.send('popup:expand'),
  openDashboard:  (route) => ipcRenderer.send('dashboard:open', route || ''),
  hideDashboard:  ()      => ipcRenderer.send('dashboard:hide'),
  openChat:       () => ipcRenderer.send("chat:open"),
  closeChat: () => ipcRenderer.send("chat:close"),

  // ── Backend URL ────────────────────────────────────────────────────────
  getBackendURL:  ()      => ipcRenderer.invoke('get-backend-url'),

  // ── Events from main process ──────────────────────────────────────────
  onAlertData:    (fn)    => {
    ipcRenderer.on('alert-data', (_, data) => fn(data));
  },

  // ── Alert injected directly into chat window ──────────────────────────
  onAlertInjected: (fn) => {
    ipcRenderer.on('chat:alert-injected', (_, data) => fn(data));
  },

  // ── Remediation result pushed back to chat ────────────────────────────
  onRemediationResult: (fn) => {
    ipcRenderer.on('chat:remediation-result', (_, data) => fn(data));
  },
  onMetricsUpdate:(fn)    => {
    ipcRenderer.on('metrics-update', (_, data) => fn(data));
  },
  onHealthUpdate: (fn)    => {
    ipcRenderer.on('health-update', (_, data) => fn(data));
  },

  // ── Environment flags ─────────────────────────────────────────────────
  isElectron: true,
  isPopup:    window.location.search.includes('popup=1'),

  // ── Remove all listeners (clean up on page unload) ────────────────────
  removeAllListeners: (channel) => ipcRenderer.removeAllListeners(channel),
});
