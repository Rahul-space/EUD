"""
backend_build.py  (FIXED)
==========================
Builds the Python backend into a standalone SysAssistBackend.exe
for Electron to bundle inside the installer via extraResources.

KEY FIX: ui/ folder is now included in PyInstaller datas so the
         FastAPI server can find index.html when running as a frozen exe.

Usage:
    python backend_build.py

Output:
    backend_dist/SysAssistBackend.exe
"""

import subprocess
import sys
import shutil
from pathlib import Path

ROOT     = Path(__file__).parent
DIST_DIR = ROOT / "backend_dist"

# ── PyInstaller spec (written to disk, run, then deleted) ──────────────────
SPEC_CONTENT = r'''
# -*- mode: python ; coding: utf-8 -*-
import sys
from pathlib import Path

block_cipher = None
ROOT = Path(SPECPATH)

try:
    from PyInstaller.utils.hooks import collect_data_files
    _starlette_data = collect_data_files("starlette")
    _plyer_data     = collect_data_files("plyer")
except Exception:
    _starlette_data = []
    _plyer_data     = []

datas = [
    # ── CRITICAL: include the UI so FastAPI can serve it ──────────────────
    (str(ROOT / "ui"),     "ui"),
    # ── Config so settings.py can find config.json ────────────────────────
    (str(ROOT / "config"), "config"),
] + _starlette_data + _plyer_data

hiddenimports = [
    "asyncio", "asyncio.windows_events", "asyncio.windows_utils",
    "uvicorn", "uvicorn.main", "uvicorn.config", "uvicorn.logging",
    "uvicorn.loops", "uvicorn.loops.auto", "uvicorn.loops.asyncio",
    "uvicorn.protocols", "uvicorn.protocols.http", "uvicorn.protocols.http.auto",
    "uvicorn.protocols.http.h11_impl",
    "uvicorn.protocols.websockets", "uvicorn.protocols.websockets.auto",
    "uvicorn.protocols.websockets.websockets_impl",
    "uvicorn.protocols.websockets.wsproto_impl",
    "uvicorn.lifespan", "uvicorn.lifespan.on", "uvicorn.lifespan.off",
    "h11", "h11._connection", "h11._events", "h11._readers", "h11._writers",
    "websockets", "websockets.legacy", "websockets.legacy.server",
    "wsproto", "wsproto.connection", "wsproto.events",
    "fastapi", "fastapi.routing", "fastapi.responses", "fastapi.middleware",
    "fastapi.middleware.cors", "fastapi.websockets",
    "starlette", "starlette.routing", "starlette.requests", "starlette.responses",
    "starlette.websockets", "starlette.middleware", "starlette.middleware.cors",
    "starlette.background", "starlette.concurrency", "starlette.datastructures",
    "starlette.exceptions", "starlette.types",
    "anyio", "anyio._backends._asyncio", "sniffio",
    "pydantic", "pydantic_core", "pydantic.deprecated.class_validators",
    "psutil", "psutil._pswindows", "psutil._pslinux", "psutil._common",
    "cryptography", "cryptography.fernet",
    "cryptography.hazmat.primitives", "cryptography.hazmat.backends",
    "cryptography.hazmat.backends.openssl",
    "plyer", "plyer.platforms",
    "plyer.platforms.win", "plyer.platforms.win.notification",
    "win32serviceutil", "win32service", "win32event", "servicemanager", "win32api",
    "winreg",
    "platform", "subprocess", "socket", "shutil", "tempfile",
    "threading", "multiprocessing", "multiprocessing.freeze_support",
    "urllib", "urllib.request", "urllib.error",
    "json", "logging", "logging.handlers", "hashlib", "base64",
    "os", "sys", "pathlib",
    "config", "config.settings",
    "utils", "utils.logger", "utils.storage",
    "agent", "agent.buffer", "agent.collector", "agent.detector",
    "agent.analyzer", "agent.health", "agent.context_builder", "agent.scheduler",
    "ai", "ai.diagnostic",
    "api", "api.server",
    "alerts", "alerts.manager", "alerts.state_manager",
    "remediation", "remediation.actions",
    "service", "service.windows_service",
]

a = Analysis(
    [str(ROOT / "main.py")],
    pathex=[str(ROOT)],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    runtime_hooks=[],
    excludes=[
        "tkinter", "matplotlib", "numpy", "scipy", "pandas", "cv2",
        "jupyter", "IPython", "test", "unittest", "doctest",
        "anthropic", "httpx", "httpcore", "openai", "aiohttp", "requests",
        "pystray", "PIL", "Pillow",
    ],
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name="SysAssistBackend",
    debug=False,
    strip=False,
    upx=False,            # UPX OFF — AV friendly
    console=False,        # No console window
    bootloader_ignore_signals=False,
    target_arch=None,
    uac_admin=False,
    icon=str(ROOT / "electron" / "assets" / "icon.ico")
         if (ROOT / "electron" / "assets" / "icon.ico").exists() else None,
)
'''


def _step(n, total, msg):
    print(f"\n  [{n}/{total}] {msg}")

def _ok(msg):   print(f"    ✓  {msg}")
def _warn(msg): print(f"    ⚠  {msg}")
def _fail(msg): print(f"    ✗  {msg}")


def main() -> bool:
    print("""
╔══════════════════════════════════════════════════════════╗
║    SysAssist — Python Backend Build                      ║
║    Output: backend_dist/SysAssistBackend.exe             ║
╚══════════════════════════════════════════════════════════╝
""")

    # ── Preflight: verify ui/index.html exists ─────────────────────────────
    _step(1, 4, "Pre-flight check")
    ui_path = ROOT / "ui" / "index.html"
    if not ui_path.exists():
        _fail(f"ui/index.html not found at: {ui_path}")
        _fail("Run: python copy_renderer.py  first, or ensure ui/ folder exists")
        return False
    _ok(f"ui/index.html found ({ui_path.stat().st_size // 1024} KB)")

    cfg_path = ROOT / "config" / "config.json"
    if not cfg_path.exists():
        _warn("config/config.json not found — will use built-in defaults")
    else:
        _ok("config/config.json found")

    # ── Write spec ─────────────────────────────────────────────────────────
    _step(2, 4, "Writing PyInstaller spec")
    spec_path = ROOT / "_backend_build.spec"
    spec_path.write_text(SPEC_CONTENT, encoding="utf-8")
    _ok(f"Spec written: {spec_path.name}")

    # ── Clean previous build ───────────────────────────────────────────────
    _step(3, 4, "Cleaning previous output")
    if DIST_DIR.exists():
        shutil.rmtree(DIST_DIR)
    DIST_DIR.mkdir()
    build_tmp = ROOT / "_backend_build_tmp"
    if build_tmp.exists():
        shutil.rmtree(build_tmp)
    _ok("Cleaned")

    # ── Run PyInstaller ────────────────────────────────────────────────────
    _step(4, 4, "Running PyInstaller (3-5 minutes…)")
    rc = subprocess.run(
        [
            sys.executable, "-m", "PyInstaller",
            "--clean",
            "--noconfirm",
            f"--distpath={DIST_DIR}",
            f"--workpath={build_tmp}",
            "--log-level=WARN",
            str(spec_path),
        ],
        cwd=str(ROOT),
    ).returncode

    # Clean up
    spec_path.unlink(missing_ok=True)
    if build_tmp.exists():
        shutil.rmtree(build_tmp, ignore_errors=True)

    if rc != 0:
        _fail("PyInstaller returned a non-zero exit code")
        return False

    # ── Report ─────────────────────────────────────────────────────────────
    for name in ("SysAssistBackend.exe", "SysAssistBackend"):
        exe = DIST_DIR / name
        if exe.exists():
            mb = exe.stat().st_size / (1024 ** 2)
            print(f"""
    ✓  {exe}
    ✓  Size: {mb:.1f} MB
    ✓  Includes: ui/index.html, config/, all Python packages

    Next step:
      npm run build     →  creates dist/SysAssist Setup *.exe
""")
            return True

    _fail("Output exe not found — check PyInstaller log above")
    return False


if __name__ == "__main__":
    import multiprocessing
    multiprocessing.freeze_support()
    ok = main()
    sys.exit(0 if ok else 1)
