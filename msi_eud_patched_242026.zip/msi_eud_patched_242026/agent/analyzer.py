"""
Trend analysis and predictive analytics engine.
Uses linear regression to detect increasing/decreasing/stable trends
and forecast future metric values.
"""
from enum import Enum
from dataclasses import dataclass
from typing import Optional
from agent.buffer import RollingBuffer


class TrendDirection(str, Enum):
    INCREASING = "increasing"
    DECREASING = "decreasing"
    STABLE = "stable"
    VOLATILE = "volatile"


@dataclass
class TrendResult:
    direction: TrendDirection
    slope: float           # units per sample
    change_rate: float     # percentage change from first to last
    confidence: float      # 0-1 how confident we are


@dataclass
class Prediction:
    metric: str
    current_value: float
    predicted_value_1h: float
    predicted_value_24h: float
    time_to_critical_hours: Optional[float]  # None if not trending to critical
    critical_threshold: float
    message: str


def linear_regression(x: list, y: list) -> tuple[float, float]:
    """Returns (slope, intercept) for simple linear regression."""
    n = len(x)
    if n < 2:
        return 0.0, y[0] if y else 0.0
    sx = sum(x)
    sy = sum(y)
    sxy = sum(xi * yi for xi, yi in zip(x, y))
    sxx = sum(xi ** 2 for xi in x)
    denom = n * sxx - sx ** 2
    if denom == 0:
        return 0.0, sy / n
    slope = (n * sxy - sx * sy) / denom
    intercept = (sy - slope * sx) / n
    return slope, intercept


def r_squared(x: list, y: list, slope: float, intercept: float) -> float:
    """Calculate R² coefficient of determination."""
    if len(y) < 2:
        return 0.0
    y_mean = sum(y) / len(y)
    ss_tot = sum((yi - y_mean) ** 2 for yi in y)
    if ss_tot == 0:
        return 1.0
    ss_res = sum((yi - (slope * xi + intercept)) ** 2 for xi, yi in zip(x, y))
    return max(0.0, 1 - ss_res / ss_tot)


class TrendAnalyzer:
    """Analyzes metric trends using linear regression."""

    STABLE_THRESHOLD = 0.5      # slope < 0.5% per sample is stable
    VOLATILE_VARIANCE = 15.0    # high variance = volatile

    def analyze(self, buffer: RollingBuffer, sample_interval_seconds: int = 5) -> TrendResult:
        values = buffer.values()
        if len(values) < 3:
            return TrendResult(
                direction=TrendDirection.STABLE,
                slope=0.0,
                change_rate=0.0,
                confidence=0.0
            )

        x = list(range(len(values)))
        slope, intercept = linear_regression(x, values)
        r2 = r_squared(x, values, slope, intercept)

        first, last = values[0], values[-1]
        change_rate = ((last - first) / max(first, 1.0)) * 100

        # Check variance for volatility
        avg = sum(values) / len(values)
        variance = sum((v - avg) ** 2 for v in values) / len(values)
        std_dev = variance ** 0.5

        if std_dev > self.VOLATILE_VARIANCE and r2 < 0.5:
            direction = TrendDirection.VOLATILE
        elif abs(slope) < self.STABLE_THRESHOLD:
            direction = TrendDirection.STABLE
        elif slope > 0:
            direction = TrendDirection.INCREASING
        else:
            direction = TrendDirection.DECREASING

        return TrendResult(
            direction=direction,
            slope=round(slope, 3),
            change_rate=round(change_rate, 1),
            confidence=round(r2, 2),
        )


class PredictiveAnalyzer:
    """Forecasts future metric values based on current trends."""

    CRITICAL_THRESHOLDS = {
        "cpu": 85.0,
        "memory": 80.0,
        "disk": 90.0,
        "gpu": 90.0,
    }

    def predict(
        self,
        metric: str,
        buffer: RollingBuffer,
        sample_interval_seconds: int,
    ) -> Optional[Prediction]:
        values = buffer.values()
        if len(values) < 4:
            return None

        current = values[-1]
        x = list(range(len(values)))
        slope, intercept = linear_regression(x, values)

        # Samples per hour / 24h
        samples_per_hour = 3600 / max(sample_interval_seconds, 1)
        samples_per_day = samples_per_hour * 24

        n = len(values)
        pred_1h = slope * (n + samples_per_hour) + intercept
        pred_24h = slope * (n + samples_per_day) + intercept

        # Clamp predictions to [0, 100] for percentage metrics
        if metric in ("cpu", "memory", "disk", "gpu"):
            pred_1h = max(0.0, min(100.0, pred_1h))
            pred_24h = max(0.0, min(100.0, pred_24h))

        critical = self.CRITICAL_THRESHOLDS.get(metric, 90.0)
        time_to_critical = None

        if slope > 0.01 and current < critical:
            samples_to_critical = (critical - intercept - slope * n) / slope
            if samples_to_critical > 0:
                hours = (samples_to_critical * sample_interval_seconds) / 3600
                if hours < 168:  # Only predict up to 7 days out
                    time_to_critical = round(hours, 1)

        message = self._build_message(metric, current, pred_1h, pred_24h, time_to_critical, critical)

        return Prediction(
            metric=metric,
            current_value=round(current, 1),
            predicted_value_1h=round(pred_1h, 1),
            predicted_value_24h=round(pred_24h, 1),
            time_to_critical_hours=time_to_critical,
            critical_threshold=critical,
            message=message,
        )

    def _build_message(
        self, metric: str, current: float,
        pred_1h: float, pred_24h: float,
        ttc: Optional[float], critical: float
    ) -> str:
        unit = "%" if metric in ("cpu", "memory", "disk", "gpu") else "ms"
        lines = [f"{metric.upper()} currently at {current:.1f}{unit}."]

        if abs(pred_1h - current) > 2:
            direction = "rise" if pred_1h > current else "drop"
            lines.append(f"Expected to {direction} to {pred_1h:.1f}{unit} in 1 hour.")

        if ttc is not None:
            if ttc < 1:
                lines.append(f"⚠ Critical threshold ({critical}{unit}) may be reached in < 1 hour!")
            elif ttc < 24:
                lines.append(f"⚠ May reach critical threshold in ~{ttc:.1f} hours.")
            else:
                days = ttc / 24
                lines.append(f"Critical threshold projected in ~{days:.1f} days.")

        return " ".join(lines)
