import logging
from typing import Optional

from agent.context_builder import DiagnosticContext
from agent.tools import kill_process, clear_temp_files

logger = logging.getLogger(__name__)


class AutoRemediator:

    SAFE_PROCESSES = ["chrome", "msedge", "firefox", "teams", "slack"]
    BLOCKED_PROCESSES = ["system", "svchost", "wininit", "csrss"]

    def should_auto_fix(self, context: DiagnosticContext) -> bool:
        """
        Decide if auto remediation should run.
        """
        if not context or not context.violations:
            return False

        # Only auto-fix critical issues
        for v in context.violations:
            if v.get("severity") == "critical":
                return True

        return False

    def execute(self, context: DiagnosticContext) -> dict:
        """
        Perform safe remediation actions.
        """
        actions_taken = []

        try:
            # Example 1: High CPU → kill top process
            if context.top_processes:
                top = context.top_processes[0]
                pname = (top.get("name") or "").lower()

                if pname and pname not in self.BLOCKED_PROCESSES:
                    if any(p in pname for p in self.SAFE_PROCESSES):
                        result = kill_process(pname)
                        actions_taken.append(f"Killed process: {pname}")
                        logger.info(result)

            # Example 2: Disk high → clear temp
            for v in context.violations:
                if v.get("metric") == "disk":
                    result = clear_temp_files()
                    actions_taken.append("Cleared temp files")
                    logger.info(result)

        except Exception as e:
            logger.error(f"Auto-remediation error: {e}")

        return {
            "actions_taken": actions_taken,
            "status": "completed" if actions_taken else "no_action"
        }