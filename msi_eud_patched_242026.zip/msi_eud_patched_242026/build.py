"""
SysAssist Build Script — v2.2.0
================================
One command to go from source → distributable SysAssist.exe

Usage:
    python build.py            # standard build (console=True)
    python build.py --silent   # production build (console=False, no terminal)
    python build.py --debug    # verbose PyInstaller logging
"""

import subprocess
import sys
import shutil
import os
import re
import argparse
from pathlib import Path

ROOT  = Path(__file__).parent
DIST  = ROOT / "dist"
BUILD = ROOT / "build"
SPEC  = ROOT / "sysassist.spec"


def run(cmd: list, **kwargs) -> int:
    print(f"    $ {' '.join(str(c) for c in cmd)}")
    return subprocess.run(cmd, **kwargs).returncode


def step(n, title):
    print(f"\n{'═'*60}")
    print(f"  STEP {n}  {title}")
    print(f"{'═'*60}")


ok   = lambda m: print(f"    ✓  {m}")
warn = lambda m: print(f"    ⚠  {m}")
fail = lambda m: print(f"    ✗  {m}")
info = lambda m: print(f"    ·  {m}")


# ── Pre-flight ─────────────────────────────────────────────────────────────

def check_python():
    maj, min_ = sys.version_info[:2]
    info(f"Python {maj}.{min_}.{sys.version_info[2]}")
    if maj < 3 or (maj == 3 and min_ < 10):
        fail("Python 3.10+ required"); return False
    ok("Python version OK"); return True


def install_deps():
    rc = run([sys.executable, "-m", "pip", "install", "-r",
              str(ROOT / "requirements.txt"), "--upgrade", "--quiet"])
    if rc != 0: fail("pip install failed"); return False

    # pywin32 post-install step (Windows only)
    if sys.platform == "win32":
        try:
            run([sys.executable, "-m", "pywin32_postinstall", "-install"],
                capture_output=True)
        except Exception:
            pass
    ok("Dependencies installed"); return True


# ── Clean ──────────────────────────────────────────────────────────────────

def clean():
    for d in [DIST, BUILD]:
        if d.exists():
            shutil.rmtree(d)
            ok(f"Removed {d.name}/")
    for p in ROOT.rglob("*.pyc"): p.unlink()
    for p in ROOT.rglob("__pycache__"): shutil.rmtree(p, ignore_errors=True)
    ok("Cleaned build artefacts")


# ── Spec patch ─────────────────────────────────────────────────────────────

def patch_spec(silent: bool):
    """Toggle console=True/False in the spec."""
    text = SPEC.read_text(encoding="utf-8")
    if silent:
        text = re.sub(r"console\s*=\s*True",  "console      = False", text)
        ok("console=False (silent mode)")
    else:
        text = re.sub(r"console\s*=\s*False", "console      = True",  text)
        ok("console=True (debug mode)")
    SPEC.write_text(text, encoding="utf-8")


# ── Build ──────────────────────────────────────────────────────────────────

def build(debug: bool) -> bool:
    cmd = [
        sys.executable, "-m", "PyInstaller",
        "--clean", "--noconfirm",
        f"--log-level={'DEBUG' if debug else 'WARN'}",
        str(SPEC),
    ]
    rc = run(cmd, cwd=str(ROOT))
    if rc != 0:
        fail("PyInstaller failed — check output above")
        return False
    return True


# ── Post-build ─────────────────────────────────────────────────────────────

def report():
    for name in ("SysAssist.exe", "SysAssist"):
        exe = DIST / name
        if exe.exists():
            mb = exe.stat().st_size / (1024 ** 2)
            print(f"""
╔══════════════════════════════════════════════════════════════╗
║                  BUILD SUCCESSFUL  ✓                         ║
╠══════════════════════════════════════════════════════════════╣
║  Executable  : {str(exe):<45s}║
║  Size        : {f'{mb:.1f} MB':<45s}║
╠══════════════════════════════════════════════════════════════╣
║  HOW TO INSTALL                                              ║
║                                                              ║
║  1. Right-click SysAssist.exe → Run as Administrator         ║
║     (Needed only for the first-time install step)            ║
║                                                              ║
║  2. Or install the service manually:                         ║
║     SysAssist.exe --install                                  ║
║                                                              ║
║  3. Regular launch (no admin needed after install):          ║
║     Double-click SysAssist.exe                              ║
║                                                              ║
║  ANTIVIRUS — If flagged as suspicious:                       ║
║  A) Add dist\\ folder as Windows Defender exclusion           ║
║  B) Submit to Microsoft: aka.ms/avsubmit                     ║
║  C) Code-sign the .exe with a trusted certificate            ║
║                                                              ║
║  UNINSTALL:                                                  ║
║     SysAssist.exe --uninstall                               ║
╚══════════════════════════════════════════════════════════════╝""")
            return
    fail("Executable not found in dist/")


# ── Main ───────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="SysAssist build script")
    parser.add_argument("--silent", action="store_true",
                        help="Build with console=False (no terminal window)")
    parser.add_argument("--debug",  action="store_true",
                        help="Verbose PyInstaller output")
    args = parser.parse_args()

    print("""
╔══════════════════════════════════════════════════════════════╗
║           SysAssist Build Pipeline  v2.2.0                   ║
╚══════════════════════════════════════════════════════════════╝""")

    step("1/5", "Pre-flight checks")
    if not check_python(): sys.exit(1)

    step("2/5", "Installing / updating dependencies")
    if not install_deps(): sys.exit(1)

    step("3/5", "Cleaning previous build")
    clean()

    step("4/5", f"Running PyInstaller ({'silent' if args.silent else 'console'} mode)")
    patch_spec(silent=args.silent)
    if not build(debug=args.debug): sys.exit(1)

    step("5/5", "Post-build report")
    report()


if __name__ == "__main__":
    main()
