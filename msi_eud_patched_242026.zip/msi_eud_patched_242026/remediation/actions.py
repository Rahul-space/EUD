"""
System remediation actions.
Provides safe, controlled operations for resolving common system issues.
"""
import os
import sys
import shutil
import psutil
import logging
import platform
import subprocess
import tempfile
from dataclasses import dataclass
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class RemediationResult:
    success: bool
    action: str
    message: str
    details: Optional[str] = None


class RemediationEngine:
    """Executes system remediation actions safely."""

    def kill_process(self, pid: int, force: bool = False) -> RemediationResult:
        """Terminate a process by PID."""
        try:
            proc = psutil.Process(pid)
            name = proc.name()
            if force:
                proc.kill()
            else:
                proc.terminate()
            return RemediationResult(
                success=True,
                action="kill_process",
                message=f"Process '{name}' (PID {pid}) terminated successfully.",
                details=f"Signal: {'SIGKILL' if force else 'SIGTERM'}",
            )
        except psutil.NoSuchProcess:
            return RemediationResult(
                success=False, action="kill_process",
                message=f"Process PID {pid} not found (may have already exited)."
            )
        except psutil.AccessDenied:
            return RemediationResult(
                success=False, action="kill_process",
                message=f"Access denied. Cannot terminate PID {pid} (insufficient permissions).",
                details="Try running SysAssist as Administrator/root."
            )
        except Exception as e:
            return RemediationResult(
                success=False, action="kill_process",
                message=f"Failed to kill process: {str(e)}"
            )

    def clear_temp_files(self) -> RemediationResult:
        """Clear system temporary files."""
        freed_bytes = 0
        errors = []
        temp_dirs = []

        # Platform-specific temp directories
        temp_dirs.append(tempfile.gettempdir())

        if platform.system() == "Windows":
            for env_var in ["TEMP", "TMP", "LOCALAPPDATA"]:
                path = os.environ.get(env_var, "")
                if path:
                    temp_dirs.append(path)
            # Windows prefetch
            prefetch = os.path.join(os.environ.get("WINDIR", "C:\\Windows"), "Prefetch")
            if os.path.exists(prefetch):
                temp_dirs.append(prefetch)
        else:
            temp_dirs.extend(["/tmp", "/var/tmp"])
            if os.path.expanduser("~"):
                temp_dirs.append(os.path.join(os.path.expanduser("~"), ".cache"))

        seen = set()
        for temp_dir in temp_dirs:
            if not os.path.isdir(temp_dir) or temp_dir in seen:
                continue
            seen.add(temp_dir)
            try:
                for item in os.listdir(temp_dir):
                    item_path = os.path.join(temp_dir, item)
                    try:
                        if os.path.isfile(item_path) or os.path.islink(item_path):
                            size = os.path.getsize(item_path)
                            os.unlink(item_path)
                            freed_bytes += size
                        elif os.path.isdir(item_path):
                            size = self._dir_size(item_path)
                            shutil.rmtree(item_path, ignore_errors=True)
                            freed_bytes += size
                    except (PermissionError, OSError):
                        pass
            except Exception as e:
                errors.append(str(e))

        freed_mb = freed_bytes / (1024 ** 2)
        return RemediationResult(
            success=True,
            action="clear_temp_files",
            message=f"Cleared {freed_mb:.1f} MB of temporary files.",
            details=f"Scanned {len(seen)} directories. Errors: {len(errors)}" if errors else None,
        )

    def _dir_size(self, path: str) -> int:
        total = 0
        try:
            for dirpath, _, filenames in os.walk(path):
                for f in filenames:
                    try:
                        total += os.path.getsize(os.path.join(dirpath, f))
                    except OSError:
                        pass
        except Exception:
            pass
        return total

    def restart_service(self, service_name: str) -> RemediationResult:
        """Restart a system service."""
        try:
            if platform.system() == "Windows":
                result = subprocess.run(
                    ["sc", "stop", service_name],
                    capture_output=True, text=True, timeout=15
                )
                subprocess.run(
                    ["sc", "start", service_name],
                    capture_output=True, text=True, timeout=15
                )
            else:
                result = subprocess.run(
                    ["systemctl", "restart", service_name],
                    capture_output=True, text=True, timeout=30
                )
                if result.returncode != 0:
                    return RemediationResult(
                        success=False, action="restart_service",
                        message=f"Failed to restart '{service_name}': {result.stderr.strip()}"
                    )

            return RemediationResult(
                success=True, action="restart_service",
                message=f"Service '{service_name}' restarted successfully.",
            )
        except subprocess.TimeoutExpired:
            return RemediationResult(
                success=False, action="restart_service",
                message=f"Timeout while restarting '{service_name}'."
            )
        except Exception as e:
            return RemediationResult(
                success=False, action="restart_service",
                message=f"Error restarting service: {str(e)}"
            )

    def reset_network(self) -> RemediationResult:
        """Reset network adapters / flush DNS."""
        try:
            if platform.system() == "Windows":
                cmds = [
                    ["ipconfig", "/flushdns"],
                    ["netsh", "winsock", "reset"],
                    ["netsh", "int", "ip", "reset"],
                ]
                for cmd in cmds:
                    subprocess.run(cmd, capture_output=True, timeout=15)
                return RemediationResult(
                    success=True, action="reset_network",
                    message="Network reset complete. DNS flushed, Winsock and IP stack reset.",
                    details="A system restart may be required for full effect."
                )
            else:
                cmds = [
                    ["systemd-resolve", "--flush-caches"],
                ]
                for cmd in cmds:
                    try:
                        subprocess.run(cmd, capture_output=True, timeout=15)
                    except Exception:
                        pass
                return RemediationResult(
                    success=True, action="reset_network",
                    message="Network DNS cache flushed.",
                )
        except Exception as e:
            return RemediationResult(
                success=False, action="reset_network",
                message=f"Network reset failed: {str(e)}"
            )

    def optimize_memory(self) -> RemediationResult:
        """Attempt to free memory by suggesting process optimization."""
        try:
            # On Windows, trigger working set trim
            if platform.system() == "Windows":
                import ctypes
                ctypes.windll.psapi.EmptyWorkingSet(ctypes.windll.kernel32.GetCurrentProcess())
            return RemediationResult(
                success=True, action="optimize_memory",
                message="Memory optimization requested. Working sets trimmed for accessible processes.",
            )
        except Exception as e:
            return RemediationResult(
                success=False, action="optimize_memory",
                message=f"Memory optimization failed: {str(e)}"
            )

    def get_available_actions(self) -> list[dict]:
        return [
            {"id": "clear_temp", "label": "Clear Temp Files", "icon": "🗑️",
             "description": "Delete temporary files to free disk space"},
            {"id": "reset_network", "label": "Reset Network", "icon": "🌐",
             "description": "Flush DNS and reset network adapters"},
            {"id": "optimize_memory", "label": "Optimize Memory", "icon": "🧹",
             "description": "Free unused memory from running processes"},
            {"id": "kill_process", "label": "Kill Process", "icon": "⛔",
             "description": "Terminate a specific process by PID (requires PID)"},
            {"id": "restart_service", "label": "Restart Service", "icon": "🔄",
             "description": "Restart a system service by name"},
        ]
