"""
SysAssist Launcher — Silent Background + Tray Mode
===================================================
Used when you want SysAssist to run silently (no console window) with a
system-tray icon. This is the entry point for the production .exe after
the service has already started the backend, or as a standalone combined
process during user-session start.

How it fits in the overall architecture:
  Windows Service  → runs main.py --agent (backend only, before login)
  User login       → runs launcher.py    (tray icon, browser open)

Both communicate via the local HTTP API on 127.0.0.1:8765.

To use this as the .exe entry point instead of main.py:
    Edit sysassist.spec: change Analysis([...]) to launcher.py
    Then rebuild with python build.py --silent
"""

# ── MUST be first ──────────────────────────────────────────────────────────
import multiprocessing
multiprocessing.freeze_support()

import sys
import os
import platform
import threading
import webbrowser
import time
import socket
import logging

# ── Path fix for frozen .exe ───────────────────────────────────────────────
if getattr(sys, "frozen", False):
    sys.path.insert(0, sys._MEIPASS)   # noqa: SLF001
    sys.path.insert(0, os.path.dirname(sys.executable))
else:
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# ── Windows event-loop policy ──────────────────────────────────────────────
if platform.system() == "Windows":
    import asyncio as _asyncio
    _asyncio.set_event_loop_policy(_asyncio.WindowsProactorEventLoopPolicy())

import asyncio

# ── Logging + config (imported after path fix) ─────────────────────────────
from utils.logger   import setup_logging, get_logger, CrashHandler
from config.settings import settings

_root_log = setup_logging(
    level        = settings.log_level,
    log_dir      = settings.log_dir,
    max_bytes    = settings.log_max_bytes,
    backup_count = settings.log_backup_count,
)
CrashHandler(_root_log)
logger = get_logger("launcher")

HOST     = settings.host
PORT     = settings.port
BASE_URL = settings.dashboard_url


# ── Backend availability ───────────────────────────────────────────────────

def _backend_ready(timeout: float = 2.0) -> bool:
    try:
        with socket.create_connection((HOST, PORT), timeout=timeout):
            return True
    except (ConnectionRefusedError, OSError):
        return False


def _wait_for_backend(timeout: float = 25.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        if _backend_ready():
            return True
        time.sleep(0.3)
    return False


# ── Agent subprocess starter ───────────────────────────────────────────────

def _start_agent_subprocess():
    """Start the monitoring backend as a detached subprocess."""
    import subprocess
    try:
        flags = subprocess.CREATE_NO_WINDOW if platform.system() == "Windows" else 0

        if getattr(sys, "frozen", False):
            cmd = [sys.executable, "--agent"]
        else:
            cmd = [sys.executable, os.path.join(
                os.path.dirname(os.path.abspath(__file__)), "main.py"
            ), "--agent"]

        subprocess.Popen(cmd, creationflags=flags)
        logger.info(f"Started agent subprocess: {' '.join(cmd)}")
    except Exception as exc:
        logger.error(f"Could not start agent subprocess: {exc}")


# ── Tray icon drawing ──────────────────────────────────────────────────────

def _make_tray_icon(health: int = 100):
    """
    Draw a 64×64 tray icon whose colour reflects system health.
    Requires Pillow. Returns None if Pillow is not installed.
    """
    try:
        from PIL import Image, ImageDraw, ImageFont
        img  = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        # Health → colour
        if health >= 80:
            fill = (0, 212, 160, 255)      # teal   — healthy
        elif health >= 55:
            fill = (245, 158, 11, 255)     # amber  — degraded
        else:
            fill = (239, 68, 68, 255)      # red    — critical

        draw.ellipse([4, 4, 60, 60], fill=fill)

        # Letter 'S' centred on icon
        try:
            font = ImageFont.truetype("arial.ttf", 30)
        except OSError:
            font = ImageFont.load_default()

        draw.text((20, 16), "S", fill=(10, 12, 18, 255), font=font)
        return img

    except ImportError:
        logger.debug("Pillow not installed — tray icon will use fallback")
        try:
            from PIL import Image
            return Image.new("RGBA", (16, 16), (0, 212, 160, 255))
        except Exception:
            return None
    except Exception as exc:
        logger.debug(f"Icon draw error: {exc}")
        return None


# ── Alert popup callback ───────────────────────────────────────────────────

def _show_alert_popup(state):
    """Called by AlertStateManager when a smart popup should fire."""
    try:
        from plyer import notification
        icons = {"critical": "⛔", "warning": "⚠️", "info": "ℹ️"}
        notification.notify(
            title   = f"{icons.get(state.severity,'⚠️')} SysAssist — {state.severity.upper()}",
            message = state.message[:200],
            app_name= "SysAssist AI",
            timeout = 15,
        )
        logger.debug(f"Desktop notification sent for [{state.metric}]")
    except Exception as exc:
        logger.debug(f"Desktop notification failed: {exc}")


# ── Health poller ──────────────────────────────────────────────────────────

class HealthPoller(threading.Thread):
    """Polls /api/metrics every N seconds and updates the tray icon + tooltip."""

    def __init__(self, icon_ref: list, poll_interval: int = 10):
        super().__init__(daemon=True, name="health-poller")
        self._icon_ref     = icon_ref   # [pystray.Icon] — list so we can update in-place
        self._interval     = poll_interval
        self._health_score = 100
        self._health_label = "Loading"
        self._violations   = 0
        self._paused       = False

    def run(self):
        import urllib.request, json
        while True:
            try:
                req = urllib.request.Request(f"{BASE_URL}/api/metrics")
                with urllib.request.urlopen(req, timeout=3) as resp:
                    data = json.loads(resp.read().decode())
                h = data.get("health", {})
                self._health_score = h.get("score", 100)
                self._health_label = h.get("label", "Unknown")
                self._violations   = len(data.get("violations", []))
                self._paused       = bool(data.get("paused", False))

                self._update_icon()
                self._update_tooltip()
            except Exception:
                pass
            time.sleep(self._interval)

    def _update_icon(self):
        icon = self._icon_ref[0] if self._icon_ref else None
        if icon is None:
            return
        try:
            img = _make_tray_icon(self._health_score)
            if img:
                icon.icon = img
        except Exception:
            pass

    def _update_tooltip(self):
        icon = self._icon_ref[0] if self._icon_ref else None
        if icon is None:
            return
        alerts = f" | ⚠ {self._violations}" if self._violations else ""
        paused = " [PAUSED]" if self._paused else ""
        icon.title = (
            f"SysAssist AI — {self._health_score}/100 "
            f"{self._health_label}{alerts}{paused}"
        )


# ── Tray application ───────────────────────────────────────────────────────

def run_with_tray():
    """Start the system-tray application. Blocks until user quits."""
    try:
        import pystray
        from PIL import Image
    except ImportError:
        logger.warning("pystray / Pillow not installed — running headless")
        run_headless()
        return

    # Make sure backend is running
    if not _backend_ready():
        logger.info("Backend not running — starting agent subprocess …")
        _start_agent_subprocess()
        if not _wait_for_backend(timeout=25.0):
            logger.error("Backend did not start — continuing with headless mode")
            run_headless()
            return

    # Wire alert state manager popup callback
    try:
        from alerts.state_manager import alert_state_manager
        alert_state_manager.register_popup_callback(_show_alert_popup)
        alert_state_manager.start()
        logger.info("AlertStateManager connected to launcher")
    except Exception as exc:
        logger.debug(f"AlertStateManager not wired: {exc}")

    # Open browser on first launch
    time.sleep(0.8)
    try:
        webbrowser.open(BASE_URL)
    except Exception:
        pass

    # Build the icon object reference (list for mutability inside threads)
    icon_ref: list = [None]

    poller = HealthPoller(icon_ref, poll_interval=10)
    poller.start()

    # ── Tray menu actions ──────────────────────────────────────────────────

    def open_dashboard(_icon=None, _item=None):
        webbrowser.open(BASE_URL)

    def open_chat(_icon=None, _item=None):
        webbrowser.open(f"{BASE_URL}/chat")
        try:
            import urllib.request, json
            req = urllib.request.Request(
                f"{BASE_URL}/api/alerts/chat-opened",
                data=b"{}",
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            urllib.request.urlopen(req, timeout=3)
        except Exception:
            pass

    def show_health(_icon=None, _item=None):
        try:
            from plyer import notification
            score = poller._health_score
            label = poller._health_label
            notification.notify(
                title   = f"SysAssist — Health: {score}/100 ({label})",
                message = "Open dashboard for full details and AI diagnostics.",
                app_name= "SysAssist AI",
                timeout = 8,
            )
        except Exception:
            webbrowser.open(BASE_URL)

    def toggle_pause(_icon=None, _item=None):
        try:
            import urllib.request
            action = "resume" if poller._paused else "pause"
            req = urllib.request.Request(
                f"{BASE_URL}/api/monitoring/{action}",
                data=b"{}",
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            urllib.request.urlopen(req, timeout=3)
            logger.info(f"Monitoring {action}d via tray")
        except Exception as exc:
            logger.debug(f"Pause toggle error: {exc}")

    def quit_app(_icon=None, _item=None):
        logger.info("Quit requested from tray menu")
        if icon_ref[0]:
            icon_ref[0].stop()
        os._exit(0)

    # ── Build menu ─────────────────────────────────────────────────────────
    menu = pystray.Menu(
        pystray.MenuItem("Open Dashboard",      open_dashboard,  default=True),
        pystray.MenuItem("Open AI Chat",        open_chat),
        pystray.MenuItem("View Device Health",  show_health),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem(
            "Pause Monitoring",
            toggle_pause,
            checked=lambda _item: poller._paused,
        ),
        pystray.Menu.SEPARATOR,
        pystray.MenuItem("Exit Agent",          quit_app),
    )

    # ── Create icon ────────────────────────────────────────────────────────
    img = _make_tray_icon(100)
    if img is None:
        logger.error("Cannot create tray icon image — Pillow required")
        run_headless()
        return

    icon = pystray.Icon(
        name  = "SysAssist",
        icon  = img,
        title = f"SysAssist AI — {BASE_URL}",
        menu  = menu,
    )
    icon_ref[0] = icon

    logger.info("Tray icon starting …")
    icon.run()     # blocks until icon.stop() is called


# ── Headless fallback ──────────────────────────────────────────────────────

def run_headless():
    """Run without a tray icon — opens browser and blocks indefinitely."""
    if not _backend_ready():
        _start_agent_subprocess()
        _wait_for_backend(25.0)

    try:
        webbrowser.open(BASE_URL)
    except Exception:
        pass

    logger.info(f"Headless mode — dashboard at {BASE_URL}")
    try:
        while True:
            time.sleep(60)
    except KeyboardInterrupt:
        pass


# ── Entry point ────────────────────────────────────────────────────────────

def main():
    args = set(sys.argv[1:])
    if "--headless" in args:
        run_headless()
    else:
        run_with_tray()


if __name__ == "__main__":
    main()
