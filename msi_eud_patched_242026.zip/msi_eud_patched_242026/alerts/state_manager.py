"""
Smart Alert State Manager
Controls the full popup / alert lifecycle to prevent alert fatigue.

State machine:
  IDLE → TRIGGERED → POPUP_SHOWN → (CHAT_OPEN | IGNORED)
  CHAT_OPEN → RESOLVED → IDLE
  IGNORED   → REMINDER (after cooldown) → POPUP_SHOWN
  RESOLVED  → IDLE

Rules:
  • Only one active popup per metric at a time
  • If chat window is open → suppress further popups for that metric
  • If popup is ignored → re-notify after popup_reminder_seconds (default 30s)
  • When violation clears → auto-resolve and reset state
  • Max one desktop notification per cooldown window
"""

import time
import threading
import webbrowser
import logging
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional, Callable

logger = logging.getLogger(__name__)


class AlertPhase(Enum):
    IDLE         = auto()   # No active alert for this metric
    TRIGGERED    = auto()   # Alert detected, not yet shown
    POPUP_SHOWN  = auto()   # Popup displayed to user
    CHAT_OPEN    = auto()   # User opened chatbot — suppress further popups
    IGNORED      = auto()   # User dismissed / didn't interact
    RESOLVED     = auto()   # Violation cleared


@dataclass
class MetricAlertState:
    metric:         str
    severity:       str
    phase:          AlertPhase = AlertPhase.IDLE
    triggered_at:   float      = 0.0
    popup_shown_at: float      = 0.0
    last_reminded:  float      = 0.0
    alert_id:       str        = ""
    message:        str        = ""
    auto_diagnosis: str        = ""    # Pre-generated AI diagnosis
    acknowledged:   bool       = False


class AlertStateManager:
    """
    Manages alert state for every monitored metric independently.
    Thread-safe. Integrated with tray notifications and browser auto-open.
    """

    def __init__(self):
        self._states:   dict[str, MetricAlertState] = {}
        self._lock      = threading.Lock()
        self._reminder_thread: Optional[threading.Thread] = None
        self._running   = False

        # Callbacks injected by the tray app / server
        self._on_popup:  Optional[Callable] = None    # fn(state) → show desktop notification
        self._on_resolve: Optional[Callable] = None   # fn(metric)

        # Global flags
        self.chat_session_open: bool = False   # Set True when browser chat page opens

        # Import settings lazily to avoid circular imports
        from config.settings import settings
        self._settings = settings

    # ── Lifecycle ──────────────────────────────────────────────────────────

    def start(self):
        self._running = True
        self._reminder_thread = threading.Thread(
            target  = self._reminder_loop,
            daemon  = True,
            name    = "alert-reminder",
        )
        self._reminder_thread.start()
        logger.info("AlertStateManager started")

    def stop(self):
        self._running = False

    # ── Main interface ─────────────────────────────────────────────────────

    def on_violation_detected(
        self,
        metric:    str,
        severity:  str,
        message:   str,
        alert_id:  str,
        diagnosis: str = "",
    ):
        """
        Called by alerts/manager.py when a sustained violation is detected.
        Implements the full smart-popup logic.
        """
        with self._lock:
            state = self._states.get(metric)

            # Already in an active non-idle phase → check what to do
            if state and state.phase not in (AlertPhase.IDLE, AlertPhase.RESOLVED):
                if state.phase == AlertPhase.CHAT_OPEN:
                    logger.debug(f"[{metric}] Chat open — suppressing popup")
                    return
                if state.phase == AlertPhase.POPUP_SHOWN:
                    logger.debug(f"[{metric}] Popup already shown — waiting for reminder timer")
                    return
                # Phase is IGNORED or TRIGGERED — allow re-trigger
            else:
                # Fresh alert
                state = MetricAlertState(
                    metric      = metric,
                    severity    = severity,
                    message     = message,
                    alert_id    = alert_id,
                    auto_diagnosis = diagnosis,
                    triggered_at   = time.time(),
                )
                self._states[metric] = state

            # ── Show popup ────────────────────────────────────────────────
            state.phase          = AlertPhase.POPUP_SHOWN
            state.popup_shown_at = time.time()
            state.severity       = severity
            state.message        = message
            state.auto_diagnosis = diagnosis
            state.alert_id       = alert_id

        logger.info(f"[{metric}] Alert popup triggered — severity={severity}")
        self._show_popup(state)

    def on_chat_opened(self, alert_id: str = ""):
        """Call when the user opens the chatbot (browser navigates to /chat)."""
        with self._lock:
            self.chat_session_open = True
            for state in self._states.values():
                if state.phase in (AlertPhase.POPUP_SHOWN, AlertPhase.IGNORED, AlertPhase.TRIGGERED):
                    if not alert_id or state.alert_id == alert_id:
                        state.phase = AlertPhase.CHAT_OPEN
                        logger.info(f"[{state.metric}] Chat opened — popup suppressed")

    def on_chat_closed(self):
        """Call when user closes the chat tab."""
        with self._lock:
            self.chat_session_open = False
            for state in self._states.values():
                if state.phase == AlertPhase.CHAT_OPEN:
                    # Downgrade to ignored so reminder loop picks it up
                    state.phase = AlertPhase.IGNORED

    def on_violation_cleared(self, metric: str):
        """Call when the metric drops below threshold."""
        with self._lock:
            state = self._states.get(metric)
            if state and state.phase != AlertPhase.IDLE:
                state.phase = AlertPhase.RESOLVED
                logger.info(f"[{metric}] Violation cleared — alert resolved")
                if self._on_resolve:
                    threading.Thread(target=self._on_resolve, args=(metric,), daemon=True).start()

    def on_user_acknowledged(self, alert_id: str):
        """User clicked Acknowledge in the UI."""
        with self._lock:
            for state in self._states.values():
                if state.alert_id == alert_id:
                    state.acknowledged = True
                    state.phase = AlertPhase.IGNORED
                    logger.info(f"[{state.metric}] Alert acknowledged by user")

    def get_active_states(self) -> list[dict]:
        """Return active alert states for the REST API."""
        with self._lock:
            return [
                {
                    "metric":       s.metric,
                    "severity":     s.severity,
                    "phase":        s.phase.name,
                    "message":      s.message,
                    "alert_id":     s.alert_id,
                    "triggered_at": s.triggered_at,
                    "diagnosis":    s.auto_diagnosis,
                }
                for s in self._states.values()
                if s.phase not in (AlertPhase.IDLE, AlertPhase.RESOLVED)
            ]

    def register_popup_callback(self, fn: Callable):
        self._on_popup = fn

    def register_resolve_callback(self, fn: Callable):
        self._on_resolve = fn

    # ── Popup execution ────────────────────────────────────────────────────

    def _show_popup(self, state: MetricAlertState):
        """Show desktop notification and open chatbot with pre-loaded diagnosis."""
        # Desktop notification (via plyer)
        if self._settings.desktop_notifications:
            self._send_desktop_notification(state)

        # Auto-open chatbot with pre-loaded diagnosis
        if self._settings.auto_open_chatbot:
            self._open_chatbot_with_diagnosis(state)

        # Fire external callback (used by tray icon)
        if self._on_popup:
            try:
                threading.Thread(
                    target  = self._on_popup,
                    args    = (state,),
                    daemon  = True,
                ).start()
            except Exception as exc:
                logger.debug(f"Popup callback error: {exc}")

    def _send_desktop_notification(self, state: MetricAlertState):
        try:
            from plyer import notification
            icons = {"critical": "⛔", "warning": "⚠️", "info": "ℹ️"}
            icon  = icons.get(state.severity, "⚠️")
            notification.notify(
                title   = f"{icon} SysAssist — {state.severity.upper()} Alert",
                message = state.message[:200],
                app_name= "SysAssist AI",
                timeout = 12,
            )
        except Exception as exc:
            logger.debug(f"Desktop notification failed: {exc}")

    def _open_chatbot_with_diagnosis(self, state: MetricAlertState):
        """Open the dashboard chat page with the alert pre-loaded."""
        from config.settings import settings
        url = f"{settings.dashboard_url}/chat?alert_id={state.alert_id}&auto=1"
        try:
            webbrowser.open(url)
            self.on_chat_opened(state.alert_id)
        except Exception as exc:
            logger.debug(f"Browser open failed: {exc}")

    # ── Reminder loop ──────────────────────────────────────────────────────

    def _reminder_loop(self):
        """
        Background thread that re-notifies for ignored alerts every
        popup_reminder_seconds (default 30 s) until resolved or acknowledged.
        """
        reminder_interval = self._settings.popup_reminder_seconds

        while self._running:
            time.sleep(5)   # Check every 5 s, act based on elapsed time
            now = time.time()
            with self._lock:
                for metric, state in self._states.items():
                    if state.phase != AlertPhase.IGNORED:
                        continue
                    if state.acknowledged:
                        continue
                    elapsed = now - max(state.popup_shown_at, state.last_reminded)
                    if elapsed >= reminder_interval:
                        state.phase          = AlertPhase.POPUP_SHOWN
                        state.last_reminded  = now
                        state.popup_shown_at = now
                        logger.info(f"[{metric}] Reminder popup fired (ignored for {elapsed:.0f}s)")
                        # Fire outside the lock
                        reminder_state = state
                        threading.Thread(
                            target  = self._show_popup,
                            args    = (reminder_state,),
                            daemon  = True,
                        ).start()


# ── Module-level singleton ─────────────────────────────────────────────────
alert_state_manager = AlertStateManager()
