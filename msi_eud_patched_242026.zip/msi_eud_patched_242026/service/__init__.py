"""
service package
Windows NT Service wrapper for SysAssist.
"""
try:
    from service.windows_service import (
        SysAssistService,
        install_service,
        start_service,
        stop_service,
        remove_service,
        service_status,
    )
    __all__ = [
        "SysAssistService",
        "install_service",
        "start_service",
        "stop_service",
        "remove_service",
        "service_status",
    ]
except ImportError:
    # pywin32 not installed (Linux/macOS dev machine)
    __all__ = []
