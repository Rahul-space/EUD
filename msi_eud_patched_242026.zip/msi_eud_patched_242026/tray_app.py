"""
SysAssist Tray Application
===========================
Runs as the user-facing component: system-tray icon + browser launcher.
Communicates with the monitoring backend via the local HTTP API.

Tray menu:
  • Open Dashboard
  • Open AI Chat
  • View Health (submenu / tooltip)
  • Pause / Resume Monitoring
  • ── separator ──
  • Quit SysAssist

This runs as a SEPARATE PROCESS from the Windows service.
The service handles monitoring + FastAPI.
This handles the tray icon + user interaction.
"""

import multiprocessing
multiprocessing.freeze_support()

import sys
import os
import platform
import threading
import webbrowser
import time
import socket
import json
import urllib.request
import urllib.error
import logging

# ── Path fix ───────────────────────────────────────────────────────────────
_ROOT = os.path.dirname(os.path.abspath(__file__))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)
if getattr(sys, "frozen", False):
    sys.path.insert(0, sys._MEIPASS)

if platform.system() == "Windows":
    import asyncio as _asyncio
    _asyncio.set_event_loop_policy(_asyncio.WindowsProactorEventLoopPolicy())

# ── Logging setup ─────────────────────────────────────────────────────────
from utils.logger import setup_logging, get_logger, CrashHandler
from config.settings import settings

_log = setup_logging(
    level        = settings.log_level,
    log_dir      = settings.log_dir,
    max_bytes    = settings.log_max_bytes,
    backup_count = settings.log_backup_count,
    name         = "sysassist",
)
logger = get_logger("tray")
CrashHandler(_log)

BASE_URL   = settings.dashboard_url
POLL_SECS  = 10      # How often to poll the API for health info


# ── API helpers ────────────────────────────────────────────────────────────

def _api_get(path: str, timeout: float = 3.0) -> dict:
    try:
        req = urllib.request.Request(f"{BASE_URL}{path}")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode())
    except Exception:
        return {}


def _api_post(path: str, data: dict = None, timeout: float = 5.0) -> dict:
    try:
        payload = json.dumps(data or {}).encode()
        req = urllib.request.Request(
            f"{BASE_URL}{path}", data=payload,
            headers={"Content-Type": "application/json"}, method="POST",
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode())
    except Exception:
        return {}


def _wait_for_backend(timeout: float = 30.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with socket.create_connection(
                (settings.host, settings.port), timeout=0.8
            ):
                return True
        except (ConnectionRefusedError, OSError):
            time.sleep(0.5)
    return False


# ── Tray icon image ────────────────────────────────────────────────────────

def _make_icon(health_score: int = 100):
    """Draw a coloured SysAssist icon. Colour reflects health score."""
    try:
        from PIL import Image, ImageDraw, ImageFont
        size = 64
        img  = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)

        # Colour based on health
        if health_score >= 80:
            colour = (0, 212, 160, 255)    # teal  — healthy
        elif health_score >= 55:
            colour = (245, 158, 11, 255)   # amber — degraded
        else:
            colour = (239, 68, 68, 255)    # red   — critical

        draw.ellipse([4, 4, 60, 60], fill=colour)

        try:
            font = ImageFont.truetype("arial.ttf", 28)
        except Exception:
            font = ImageFont.load_default()

        draw.text((20, 16), "S", fill=(10, 12, 18, 255), font=font)
        return img

    except ImportError:
        # Fallback: tiny solid-colour image
        try:
            from PIL import Image
            return Image.new("RGBA", (16, 16), (0, 212, 160, 255))
        except Exception:
            return None


# ── Tray Application ───────────────────────────────────────────────────────

class SysAssistTray:
    """
    Main tray application class.
    Polls the backend API for health data and updates the icon / tooltip.
    """

    def __init__(self):
        self._icon        = None
        self._paused      = False
        self._health_score= 100
        self._health_label= "Loading"
        self._violations  = 0
        self._poll_thread = None

    def run(self):
        try:
            import pystray
            from PIL import Image
        except ImportError:
            logger.warning("pystray/Pillow not installed — running headless")
            self._headless_run()
            return

        logger.info("Starting tray application …")

        # Start backend if not already running
        if not _wait_for_backend(timeout=2.0):
            logger.info("Backend not up — starting it …")
            self._start_backend()
            _wait_for_backend(timeout=25.0)

        # Build tray icon
        img = _make_icon(100)
        if img is None:
            logger.error("Could not create tray icon image")
            self._headless_run()
            return

        menu = pystray.Menu(
            pystray.MenuItem("Open Dashboard",      self._open_dashboard, default=True),
            pystray.MenuItem("Open AI Chat",        self._open_chat),
            pystray.MenuItem("System Health",       self._show_health_toast),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem(
                "Pause Monitoring",
                self._toggle_pause,
                checked = lambda item: self._paused,
            ),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Quit SysAssist",      self._quit),
        )

        self._icon = pystray.Icon(
            name  = "SysAssist",
            icon  = img,
            title = "SysAssist AI — Loading …",
            menu  = menu,
        )

        # Start background health poller
        self._poll_thread = threading.Thread(
            target  = self._health_poll_loop,
            daemon  = True,
            name    = "tray-health-poll",
        )
        self._poll_thread.start()

        # Open browser on first launch
        threading.Timer(2.0, lambda: webbrowser.open(BASE_URL)).start()

        self._icon.run()

    # ── Menu actions ───────────────────────────────────────────────────────

    def _open_dashboard(self, icon=None, item=None):
        webbrowser.open(BASE_URL)

    def _open_chat(self, icon=None, item=None):
        webbrowser.open(f"{BASE_URL}/chat")
        _api_post("/api/alerts/chat-opened")

    def _show_health_toast(self, icon=None, item=None):
        data  = _api_get("/api/metrics")
        h     = data.get("health", {})
        score = h.get("score", "?")
        label = h.get("label", "?")
        summary = h.get("summary", "")
        try:
            from plyer import notification
            notification.notify(
                title   = f"SysAssist — Health: {score}/100 ({label})",
                message = summary or "All systems normal.",
                app_name= "SysAssist AI",
                timeout = 8,
            )
        except Exception:
            webbrowser.open(BASE_URL)

    def _toggle_pause(self, icon=None, item=None):
        self._paused = not self._paused
        action = "pause" if self._paused else "resume"
        _api_post(f"/api/monitoring/{action}")
        logger.info(f"Monitoring {'paused' if self._paused else 'resumed'} by user")
        self._update_tooltip()

    def _quit(self, icon=None, item=None):
        logger.info("Quit requested from tray")
        if self._icon:
            self._icon.stop()
        os._exit(0)

    # ── Health polling ─────────────────────────────────────────────────────

    def _health_poll_loop(self):
        while True:
            try:
                data = _api_get("/api/metrics", timeout=3.0)
                if data:
                    h = data.get("health", {})
                    self._health_score = h.get("score", 100)
                    self._health_label = h.get("label", "Unknown")
                    self._violations   = len(data.get("violations", []))
                    self._update_icon()
                    self._update_tooltip()
            except Exception as exc:
                logger.debug(f"Health poll error: {exc}")
            time.sleep(POLL_SECS)

    def _update_icon(self):
        if self._icon is None:
            return
        try:
            img = _make_icon(self._health_score)
            if img:
                self._icon.icon = img
        except Exception:
            pass

    def _update_tooltip(self):
        if self._icon is None:
            return
        score  = self._health_score
        label  = self._health_label
        alerts = f" | ⚠ {self._violations} alert(s)" if self._violations else ""
        paused = " [PAUSED]" if self._paused else ""
        self._icon.title = f"SysAssist AI — {score}/100 {label}{alerts}{paused}"

    # ── Popup callback (called by AlertStateManager) ───────────────────────

    def on_alert_popup(self, state):
        """Called when the alert state manager wants to show a popup."""
        try:
            from plyer import notification
            icons = {"critical": "⛔", "warning": "⚠️", "info": "ℹ️"}
            icon  = icons.get(state.severity, "⚠️")
            notification.notify(
                title   = f"{icon} SysAssist — {state.severity.upper()}",
                message = state.message[:200],
                app_name= "SysAssist AI",
                timeout = 15,
            )
        except Exception:
            pass

    # ── Backend starter ────────────────────────────────────────────────────

    def _start_backend(self):
        """Start the monitoring backend as a subprocess (fallback for non-service mode)."""
        import subprocess
        try:
            if getattr(sys, "frozen", False):
                cmd = [sys.executable, "--agent"]
            else:
                main_py = os.path.join(_ROOT, "main.py")
                cmd = [sys.executable, main_py]

            subprocess.Popen(
                cmd,
                creationflags = subprocess.CREATE_NO_WINDOW if platform.system() == "Windows" else 0,
            )
            logger.info("Started backend process")
        except Exception as exc:
            logger.error(f"Could not start backend: {exc}")

    # ── Headless fallback ──────────────────────────────────────────────────

    def _headless_run(self):
        """Run without a tray icon — just open browser and block."""
        if not _wait_for_backend(timeout=25.0):
            self._start_backend()
            _wait_for_backend(timeout=25.0)
        webbrowser.open(BASE_URL)
        logger.info("Running in headless mode (no tray icon)")
        try:
            while True:
                time.sleep(60)
        except KeyboardInterrupt:
            pass


# ── Entry point ────────────────────────────────────────────────────────────

def main():
    app = SysAssistTray()

    # Register tray popup callback with the alert state manager
    try:
        from alerts.state_manager import alert_state_manager
        alert_state_manager.register_popup_callback(app.on_alert_popup)
        alert_state_manager.start()
    except Exception as exc:
        logger.debug(f"AlertStateManager not available in tray: {exc}")

    app.run()


if __name__ == "__main__":
    main()
